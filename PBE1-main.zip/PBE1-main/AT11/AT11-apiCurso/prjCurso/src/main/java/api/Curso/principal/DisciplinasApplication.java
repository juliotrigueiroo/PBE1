package api.Curso.principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisciplinasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisciplinasApplication.class, args);
	}
}