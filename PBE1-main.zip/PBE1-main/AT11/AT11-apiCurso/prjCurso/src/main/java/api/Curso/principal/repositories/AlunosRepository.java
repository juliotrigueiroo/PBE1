package api.Curso.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import api.Curso.principal.entities.Alunos;

public interface AlunosRepository extends JpaRepository<Alunos, Long> {

}


