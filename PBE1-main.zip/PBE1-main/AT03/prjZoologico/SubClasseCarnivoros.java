package prjZoologico;

public class SubClasseCarnivoros extends ClasseAnimal {

	//Metodos da Subclasse
	public void metodoCacar() {
		System.out.println(this.atributoNome + " está caçando!");
	}
	
	
	
}
