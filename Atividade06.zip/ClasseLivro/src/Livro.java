
public class Livro {
	
	String Titulo;
	 String Autor;
	 int numPaginas;
	double Preco ;
	
	//construtores
	
	public Livro() {
		
	}
	
	public Livro(String Titulo, String Autor, int numPaginas,double Preco) {
		this.Titulo = Titulo;
		this.Autor = Autor;
		this.numPaginas = numPaginas;
		this.Preco = Preco;
				
	}
	//getter setter

	public String getTitulo() {
		return Titulo;
	}

	public void setTitulo(String titulo) {
		Titulo = titulo;
	}

	public String getAutor() {
		return Autor;
	}

	public void setAutor(String autor) {
		Autor = autor;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	public double getPreco() {
		return Preco;
	}

	public void setPreco(double preco) {
		Preco = preco;
	}
	
	//metodos
	public void aplicarDesconto() {
		System.out.println();
	}
}
