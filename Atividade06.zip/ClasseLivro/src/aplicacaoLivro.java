package 

public class aplicacaoLivro {
	public static void main(double[] args) {
		Livro cronicas = new Livro();
		cronicas.setTitulo("Cronicas de quintiliano");
		cronicas.setAutor("primissia");
		cronicas.setnumPaginas(2222);
	}

}
