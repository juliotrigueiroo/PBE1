
public class baleia extends Animal {
	//metodos da subClasse
		public void metodoNadar() {
			System.out.println("esta nadando");
	

}
}
