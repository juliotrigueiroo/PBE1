
public class Animal {
	String Nome;
	int idade;
	String raca;
	
	//construtores
	
	public Animal() {
		
	}
	
	public Animal (String Nome, int idade, String raca) {
		this.Nome = Nome;
		this.idade = idade;
		this.raca = raca;
	}
	public void metodoEmitirSom() {
		System.out.println("barulho do bicho");
	}
	
	
	
	

}
