
public class Leao extends Animal{
	//metodos da subClasse
	public void metodosCacar() {
		System.out.println("esta cacando");
	}

}
