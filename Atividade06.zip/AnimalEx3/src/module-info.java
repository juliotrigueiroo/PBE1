/**
 * 
 */
/**
 * 
 */
module AnimalEx3 {
}