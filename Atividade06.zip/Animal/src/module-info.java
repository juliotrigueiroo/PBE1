/**
 * 
 */
/**
 * 
 */
module Animal {
}