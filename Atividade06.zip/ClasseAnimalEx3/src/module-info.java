/**
 * 
 */
/**
 * 
 */
module ClasseAnimalEx3 {
}