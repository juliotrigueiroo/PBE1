
public class aplicacaoCarro {
	public static void main(String[] args) {
		Carro mcquen = new Carro();
		mcquen.setNome("mcquen");
		mcquen.setMarca("tesla");
		mcquen.setPlaca(19203993);
		mcquen.setAno(1999);
		
		Carro math = new carro();
		math.setNome("math");
		math.setMarca("rous roici");
		math.setPlaca(29-092);
		math.setAno(9292);
		
		public exirbirInfo();
		
	}
}
