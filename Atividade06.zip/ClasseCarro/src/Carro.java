
public class Carro {
	//atributo
	String Nome;
	String Marca;
	String Placa;
	int Ano;
	
	//construtores
	
	public Carro() {
		
	}
	public Carro(String Nome, String Marca, String Placa, Int Ano) {
		this.Nome = Nome;
		this.Marca = Marca;
		this.Placa = Placa;
		this.Ano = Ano;
		
	}
	//gettes e setters
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getMarca() {
		return Marca;
	}
	public void setMarca(String marca) {
		Marca = marca;
	}
	public String getPlaca() {
		return Placa;
	}
	public void setPlaca(String placa) {
		Placa = placa;
	}
	public int getAno() {
		return Ano;
	}
	public void setAno(int ano) {
		Ano = ano;
	}
	
	//metodo
	public void exibirInfo(){
		System.out.println();
	}
	
	
	
	
	
	
}
