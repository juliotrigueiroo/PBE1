package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa{
	//Atributos
	public String matricula;
	
	//metodos
		public void realizarEmprestimo() {
			System.out.println( "Livro emprestado ");
		}
		
		public void devolverLivro() {
			System.out.println("devolveu o livro ");
		}

}
