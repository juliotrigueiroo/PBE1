package br.com.bibiotecasenai.itens;

public class Empréstimo {
	//Atributos
	
	private String numeroEmprestimo;
	

}
