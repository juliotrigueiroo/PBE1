package prjPokemonV2;

public class SubPokemonAgua extends Pokemon{
	public void surfar() {
		System.out.println("tô surfandoo");
	}
	public void canhaoAgua() {
		System.out.println("Vai canhão de aguaaa");
	}
}
