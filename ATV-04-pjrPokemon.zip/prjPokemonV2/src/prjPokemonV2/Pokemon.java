package prjPokemonV2;

public class Pokemon {
	// atributos
	String Nome;
	String Tipo;
	int Nivel;
	int Vida;
	int Defesa;

	// construtores

	public Pokemon() {

	}

	public Pokemon(String Nome, String Tipo, int Nivel, int Vida, int Defesa) {
		this.Nome = Nome;
		this.Tipo = Tipo;
		this.Nivel = Nivel;
		this.Vida = Vida;
		this.Defesa = Defesa;
	}

	// getters and setters

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public int getNivel() {
		return Nivel;
	}

	public void setNivel(int nivel) {
		Nivel = nivel;
	}

	public int getVida() {
		return Vida;
	}

	public void setVida(int vida) {
		Vida = vida;
	}

	public int getDefesa() {
		return Defesa;
	}

	public void setDefesa(int defesa) {
		Defesa = defesa;
	}

	// metodos

	public void metodoAtacar() {
		System.out.println(Nome + ": esta atacando");

	}

	public void metodoEvoluir() {
		System.out.println(Nome + ":esta atacando");
	}
	
	public void exibirInfo () {
		
	}

}
