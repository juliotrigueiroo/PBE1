package prjPokemonV2;

public class SubPokemonFogo extends Pokemon{
	public void bolaFogo() {
		System.out.println("Vai bola de fogooo");
	}
	public void explosaoFogo() {
		System.out.println("Ataque explosão de fogoo");
	}
	public void lancaChamas() {
		System.out.println("lança chamass");
	}
}
