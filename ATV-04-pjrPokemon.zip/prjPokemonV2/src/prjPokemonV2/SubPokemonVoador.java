package prjPokemonV2;

public class SubPokemonVoador extends Pokemon{
	public void voar() {
		System.out.println("to voando");
	}
	public void ataquDeAsa() {
		System.out.println("toma esse ataque");
	}
}
