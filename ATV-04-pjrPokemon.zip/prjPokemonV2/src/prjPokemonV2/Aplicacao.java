package prjPokemonV2;

public class Aplicacao {

	public static void main(String[] args) {
		Pokemon charmander = new Pokemon();
		charmander.setNome("charmander");
		charmander.setTipo("fogo");
		charmander.setNivel(8);
		charmander.setVida(22);

		Pokemon frog = new Pokemon();
		frog.setNome("frog");
		frog.setTipo("água");
		frog.setNivel(111);
		frog.setVida(444);
		
		Pokemon noibat = new Pokemon();
		noibat.setNome("noibet");
		noibat.setTipo("vento");
		noibat.setNivel(90);
		noibat.setVida(200);
		
		charmander.exibirInfo();
		charmander.metodoAtacar();
		charmander.metodoEvoluir();
		frog.exibirInfo();
		frog.metodoAtacar();
		frog.metodoEvoluir();
		noibat.exi
	}

}
